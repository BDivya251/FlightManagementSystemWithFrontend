export interface Airline {
  id: number;
  airlineName: string | null;
}
