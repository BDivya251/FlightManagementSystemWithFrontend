import { Component } from '@angular/core';

@Component({
  selector: 'app-get-all-airline',
  imports: [],
  templateUrl: './get-all-airline.html',
  styleUrl: './get-all-airline.css',
})
export class GetAllAirline {

}
